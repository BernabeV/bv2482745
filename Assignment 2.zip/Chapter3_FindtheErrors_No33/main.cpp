/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Chapter 3: Find the Errors No. 31
 * Created on January 17, 2014, 6:11 PM
 */

#include <iostream>;
//main.cpp:8:20: warning: extra tokens at end of #include directive [enabled by default]
using namespace std;

main {
    //main.cpp:12:1: error: ‘main’ does not name a type
    char name. go;
    
    cout<<"Enter your name:";
    getline>>name;
    cout<<"Hi"<<name<<endl;

    return 0;
}


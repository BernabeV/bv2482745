/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Chapter 3: Find the Errors No. 31
 * Created on January 17, 2014, 6:11 PM
 */

#include <iostream>;
//main.cpp:8:20: warning: extra tokens at end of #include directive [enabled by default]
using namespace std;

main {
    //main.cpp:12:1: error: ‘main’ does not name a type
    int number1, number2;
    
    cout<<"Enter two numbers and I will multiply\n"
    cout<<"them by 50 for you.\n"
    cin>>number1>>number2;
    number1=*50;
    number2=*50;
    cout<<number1<<"  "<<number2;

    return 0;
}


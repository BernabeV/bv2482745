/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Chapter 3: Find the Errors Number 29
 * Created on January 17, 2014, 5:37 PM
 */

#include <iostream>;
//main.cpp:8:20: warning: extra tokens at end of #include directive [enabled by default]
using namespace std;


int main() {
    const int number1, number2, product;
    //main.cpp:13:15: error: uninitialized const ‘number1’ [-fpermissive]
    //main.cpp:13:24: error: uninitialized const ‘number2’ [-fpermissive]
    //main.cpp:13:33: error: uninitialized const ‘product’ [-fpermissive]
    
    cout<<"Enter two numbers and I will multiply\n";
    cout<<"then for you.\n";
    cin>>number1>>number2;
    //main.cpp:21:8: error: ambiguous overload for ‘operator>>’ (operand types are ‘std::istream {aka std::basic_istream<char>}’ and ‘const int’)
    product=number1*number2;
    //main.cpp:23:12: error: assignment of read-only variable ‘product’
    cout<<product
    //main.cpp:27:5: error: expected ‘;’ before ‘return’
    return 0;
}


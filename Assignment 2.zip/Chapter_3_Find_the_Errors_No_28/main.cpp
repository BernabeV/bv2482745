/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Find the Errors No. 28
 * Created on January 14, 2014
 */
    //No System Library

using namespace std;
int main() 
{
    double number1, number2, sum;
    Cout << "Enter a number: ";
    //main.cpp:13:5: error: 'Cout' was not declared in this scope
    Cin << number1;
    //main.cpp:15:5: error: 'Cin' was not declared in this scope
    Cout << "Enter another number: ";
    Cin << number2;
    number1 + number2 = sum;
    //main.cpp:19:23: error: lvalue required as left operand of assignment
    Cout "the sum of the two numbers is " << sum
    //main.cpp:21:10: error: expected ';' before string constant
    return 0;
}


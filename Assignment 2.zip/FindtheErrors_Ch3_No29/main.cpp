/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Chapter 3: Find the Errors Number 29
 * Created on January 17, 2014, 5:37 PM
 */

#include <iostream>
using namespace std;


int main() {
    int number1,number2;
    float quotient;
    cout<< "Enter two numbers and I will divide\n";
    cout<< "the first by the second for you. \n;";
    cin>> number1,number2;
    quotient = float<static_cast>(number1)/number2;
    //main.cpp:18:16: error: ‘float’ is not a template
    //main.cpp:18:35: error: ‘number1’ cannot appear in a constant-expression
    //main.cpp:18:16: error: expected primary-expression before ‘float’
    //main.cpp:18:16: error: expected ‘;’ before ‘float’
    cout<<quotient
    //main.cpp:24:5: error: expected ‘;’ before ‘return’
    return 0;
}


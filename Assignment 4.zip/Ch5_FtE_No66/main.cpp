/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 5: Find the Errors - Number 66
 * Created on January 24, 2014, 9:20 PM
 */

#include <iostream>
using namespace std;

int main() {
    int num1,num2;
    char again;
    
    while (again==' y' || again==' y')
        //main.cpp:15:19: warning: multi-character character constant [-Wmultichar]
        //main.cpp:15:34: warning: multi-character character constant [-Wmultichar]
        cout<<"Enter a number: ";
        cin>>num1;
        cout<"Enter another number: ";
        cin>>num2;
        cout<<"Their sum is <<(num1+num2)<<endl;"
        cout<<"Do you want to do this again? ";
        //main.cpp:23:9: error: expected ‘;’ before ‘cout’
        cin>>again;

    return 0;
}


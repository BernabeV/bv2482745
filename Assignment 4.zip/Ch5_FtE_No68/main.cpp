/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 5: Find the Errors - Number 68
 * Created on January 24, 2014, 9:55 PM
 */

#include <iostream>
using namespace std;

int main() {
    
    int numCount, total;
    double average;
    cout<<"How many numbers do you want to average? ";
    cin>>numCount;
    for(int count=0; count < numCount;count++){
        //main.cpp:17:19: error: ‘o’ was not declared in this scope
        int num;
        cout<<"Enter a number: ";
        cin>>num;
        total+=num;
        count++;
    }
    average+total/numCount;
    cout<<"The average is << average << endl;
    //main.cpp:26:5: error: missing terminating " character
    

    return 0;
    //main.cpp:26:5: error: expected primary-expression before ‘return’
    //main.cpp:26:5: error: expected ‘;’ before ‘return’
}


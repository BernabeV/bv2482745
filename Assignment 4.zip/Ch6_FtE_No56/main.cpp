/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 6: Find the Errors - Number 56
 * Created on January 25, 2014, 4:23 PM
 */

#include <iostream>
#include <cstdlib>


void total(int value1, value2, value3)
//main.cpp:12:24: error: ‘value2’ has not been declared
//main.cpp:12:32: error: ‘value3’ has not been declared
    {
        return value1+value2+value3;
        //main.cpp:16:23: error: ‘value2’ was not declared in this scope
        //main.cpp:16:30: error: ‘value3’ was not declared in this scope
        //main.cpp:16:30: error: return-statement with a value, in function returning 'void' [-fpermissive]
    }




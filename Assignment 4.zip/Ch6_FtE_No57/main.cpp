/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 6: Find the Errors - Number 57
 * Created on January 25, 2014, 4:54 PM
 */

#include <iostream>
#include <cstdlib>


double average( int value1, int value2, int value3)
{
    double average;
    
    average=value1+value2+value3/3;
}
///usr/src/debug/cygwin-1.7.27-2/winsup/cygwin/lib/libcmain.c:39:(.text.startup+0x7e): relocation truncated to fit: R_X86_64_PC32 against undefined symbol `WinMain'

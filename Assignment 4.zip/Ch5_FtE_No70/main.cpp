/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 5: Find the Errors - Number 70
 * Created on January 24, 2014, 10:23 PM
 */

#include <iostream>
using namespace std;

int main() {
    int count=1, total;
    
    while (count<=100)
        total +=count;
    cout<<"The sum of the numbers 1-100 is ";
    cout<<total<<endl;

    return 0;
}
//It does not tell me the sum of the numbers... It doesn't even say "The sum of the numbers"

/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 6: Find the Errors - Number 58
 * Created on January 25, 2014, 5:10 PM
 */

#include <iostream>
#include <cstdlib>


void area(int length=30, int width)
//main.cpp:12:6: error: default argument missing for parameter 2 of ‘void area(int, int)’
{
    return length*width;
//main.cpp:15:19: error: return-statement with a value, in function returning 'void' [-fpermissive]
}

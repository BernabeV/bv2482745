/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 5: Find the Errors - Number 69
 * Created on January 24, 2014, 10:10 PM
 */

#include <iostream>
using namespace std;

int main() {

    int choice, num1, num2;
    
    do{
        cout<<"Enter a number: ";
        cin>>num1;
        cout<<"Enter another number: ";
        cin>>num2;
        cout<<"Their sum is "<<(num1+num2)<<endl;
        cout<<"Do you want to do this again?\n";
        cout<<"1 = yes, 0 = no\n";
        cin>>choice;
    }while (choice=1)
    return 0;
    //main.cpp:25:5: error: expected ‘;’ before ‘return’
    //If you run the program, entering "0" continues to ask for numbers.
}


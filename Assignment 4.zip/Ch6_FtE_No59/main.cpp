/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 6: Find the Errors - Number 59
 * Created on January 25, 2014, 5:27 PM
 */

#include <iostream>
#include <cstdlib>

void getValue(int value&)
//main.cpp:11:24: error: expected ‘,’ or ‘...’ before ‘&’ token
{
    cout<<"Enter a value: ";
    //main.cpp:14:5: error: ‘cout’ was not declared in this scope
    cin>>value&;
    //main.cpp:16:5: error: ‘cin’ was not declared in this scope
    //main.cpp:16:16: error: expected primary-expression before ‘;’ token
}

/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 5: Find the Errors - Number 65
 * Created on January 24, 2014, 9:11 PM
 */

#include <iostream>
using namespace std;

int main() {
    int num1 = 0, num2 = 10, result;
    num1++;
    result=++(num1+num2);
    //main.cpp:14:24: error: lvalue required as increment operand
    cout<<num1<< " " <<num2<< " "<<result;
    return 0;
}


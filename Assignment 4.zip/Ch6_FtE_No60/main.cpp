/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 6: Find the Errors - Number 60
 * Created on January 25, 2014, 5:44 PM
 */

#include <iostream>
#include <cstdlib>

int getValue()
//main.cpp:11:5: error: ambiguates old declaration ‘int getValue()’
{
    int inputValue;
    cout<<"Enter an integer: ";
    //main.cpp:15:5: error: ‘cout’ was not declared in this scope
    cin>>inputValue;
    //main.cpp:16:5: error: ‘cin’ was not declared in this scope
    return inputValue;
}
double getValue()
//main.cpp:20:17: error: new declaration ‘double getValue()’
{
    double inputValue;
    cout<<"Enter a floating-point number: ";
    //main.cpp:25:5: error: ‘cout’ was not declared in this scope
    cin>>inputValue;
    //main.cpp:27:5: error: ‘cin’ was not declared in this scope
    return inputValue;
}

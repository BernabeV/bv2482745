/* 
 * File:   main.cpp
 * Author: Bernabe Villalobos
 * Gaddis - Chapter 5: Find the Errors - Number 67
 * Created on January 24, 2014, 9:40 PM
 */

#include <iostream>
using namespace std;

int main() {

    int num, bigNum, power, count;
    
    cout<<"Enter an integer: ";
    cin>>num;
    cout<<"What power do you want it raised to? ";
    cin>>power;
    bigNum=num;
    while(count++<power);
       bigNum*=num;
       cout<<"The result is << bigNum << endl;"
      
    return 0;
       //main.cpp:24:5: error: expected ‘;’ before ‘return’
}

